package com.kony.samplejavaservice;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import com.konylabs.middleware.common.JavaService;
import com.konylabs.middleware.dataobject.Dataset;
import com.konylabs.middleware.dataobject.Param;
import com.konylabs.middleware.dataobject.Record;
import com.konylabs.middleware.dataobject.Result;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;

public class HelpCategory implements JavaService { //Implemented JavaService Interface provided by KonyLabs Inc.
	 
	public Object invoke(String serviceId, Object[] objectArray) throws Exception {
		
		Result result = new Result();
		Dataset set = new Dataset("helpCategory"); //Creating instance of Dataset for adding list of records. 
		ArrayList<Record> list_hc = new ArrayList<Record>();
		
		if(serviceId.equals("HelpCategoryService")){
			try {	 
				/*String middlewarePath = System.getProperty("middleware.home");
				String separator = System.getProperty("file.separator");
				//Produce DOM object trees from XML document i.e. place at KonyOne Server(http://sampleapps.konylabs.net)
				File fXmlFile = new File(middlewarePath + separator + "samplefiles" + separator +"JavaConnectorFiles"+ separator +"category.xml");	*/
				InputStream input = getClass().getResourceAsStream("/com/kony/xmlfiles/category.xml");	
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(input);
				doc.getDocumentElement().normalize(); 
		 
				NodeList nList = doc.getElementsByTagName("row");
		 
				for (int count = 0; count < nList.getLength(); count++) {
			 
					Node nNode = nList.item(count);			 
					System.out.println("\nCurrent Element :" + nNode.getNodeName());
			 
					if (nNode.getNodeType() == Node.ELEMENT_NODE) {
						Record record = new Record();
						Element eElement = (Element) nNode;	
						String hc_id = eElement.getElementsByTagName("field").item(0).getTextContent();
						String hc_name = eElement.getElementsByTagName("field").item(1).getTextContent();
						Param param1 = new Param("hcid", hc_id, "String");
						record.setParam(param1);
						Param param2 = new Param("hcname", hc_name, "String");
						record.setParam(param2);
						System.out.println("help_category_id : " + eElement.getElementsByTagName("field").item(0).getTextContent());
						System.out.println("name : " + eElement.getElementsByTagName("field").item(1).getTextContent());
						list_hc.add(record);
		
					}
		}
				Param param_opstatus = new Param("opstatus", "0", "String"); // Setting 'opstatus = 0' parameter to acknowledge that service is successfully respond.  
				result.setParam(param_opstatus);
				set.setRecords(list_hc);				
				result.setDataSet(set); // Final result with set of records.
				
	    } catch (Exception e) {
		e.printStackTrace();
	    }
	}
	return result;
}
	
	public static void main(String args[]) throws Exception{
		HelpCategory helpc = new HelpCategory();
		
		helpc.invoke("HelpCategoryService", null);
		
	}
	
}