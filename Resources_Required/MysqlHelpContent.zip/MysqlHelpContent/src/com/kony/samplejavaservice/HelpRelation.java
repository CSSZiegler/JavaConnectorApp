package com.kony.samplejavaservice;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import com.konylabs.middleware.common.JavaService;
import com.konylabs.middleware.dataobject.Dataset;
import com.konylabs.middleware.dataobject.Param;
import com.konylabs.middleware.dataobject.Record;
import com.konylabs.middleware.dataobject.Result;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Map;

public class HelpRelation implements JavaService {
	 
	public Object invoke(String serviceId, Object[] objectArray) throws Exception {
		Result result = new Result();
		Dataset set = new Dataset("helpRelation");
		ArrayList<Record> list_hr = new ArrayList<Record>();
		@SuppressWarnings("unchecked")
		Map<String, String> inputParam = (Map<String, String>) objectArray[1];
		String id = inputParam.get("id");
		
		if(serviceId.equals("HelpRelationService")){		
	    try {	
	    
			//Reading the file from classpath
			InputStream input = getClass().getResourceAsStream("/com/kony/xmlfiles/keyword_topic_relation.xml");	
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(input);	
			doc.getDocumentElement().normalize(); 
			NodeList nList = doc.getElementsByTagName("row");
			for (int count = 0; count < nList.getLength(); count++) {
				Node nNode = nList.item(count);					
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;					
					String hrk_id = eElement.getElementsByTagName("field").item(1).getTextContent();
					String hrt_id = null;
					if(hrk_id.equalsIgnoreCase(id)){
						hrt_id = eElement.getElementsByTagName("field").item(0).getTextContent();
						 input = getClass().getResourceAsStream("/com/kony/xmlfiles/topics.xml");	
						DocumentBuilderFactory dbFactory1 = DocumentBuilderFactory.newInstance();
						DocumentBuilder dBuilder1 = dbFactory1.newDocumentBuilder();			
						Document topic_doc = dBuilder1.parse(input);
						topic_doc.getDocumentElement().normalize();
						NodeList ntopicList = topic_doc.getElementsByTagName("row");
						for (int count1 = 0; count1 < ntopicList.getLength(); count1++) {							 
							Node nNode1 = ntopicList.item(count1);					
							if (nNode1.getNodeType() == Node.ELEMENT_NODE) {						
								Element eElement1 = (Element) nNode1;	
								if(eElement1.getElementsByTagName("field").item(0).getTextContent().equalsIgnoreCase(hrt_id)){
									System.out.println("\nname :"+eElement1.getElementsByTagName("field").item(1).getTextContent());
									String name = eElement1.getElementsByTagName("field").item(1).getTextContent();
									String url = eElement1.getElementsByTagName("field").item(3).getTextContent();
									System.out.println("help_topic_id : " + eElement1.getElementsByTagName("field").item(3).getTextContent());
									Record record = new Record();
									Param param1 = new Param("name", name, "String");
									record.setParam(param1);
									Param param2 = new Param("url", url, "String");
									record.setParam(param2);
									list_hr.add(record);
								}
							}
						}					
					}
				}
			}				
			Param param_opstatus = new Param("opstatus", "0", "String");
			result.setParam(param_opstatus);

			set.setRecords(list_hr);				
			result.setDataSet(set);
				
	    } catch (Exception e) {
		e.printStackTrace();
	    }
	}
	return result;
}
	public static void main(String args[]) throws Exception{
		HelpRelation helpr = new HelpRelation();
		
		helpr.invoke("HelpRelationService", null);
		
	}
	
}
