package com.kony.samplejavaservice;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import com.konylabs.middleware.common.JavaService;
import com.konylabs.middleware.dataobject.Dataset;
import com.konylabs.middleware.dataobject.Param;
import com.konylabs.middleware.dataobject.Record;
import com.konylabs.middleware.dataobject.Result;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class HelpTopic implements JavaService {
	 
	public Object invoke(String serviceId, Object[] objectArray) throws Exception {
		
		Result result = new Result();
		Dataset set = new Dataset("helpTopic");
		ArrayList<Record> list_hc = new ArrayList<Record>();
		@SuppressWarnings("unchecked")
		Map<String, String> inputParam = (Map<String, String>) objectArray[1]; //Getting i/p parameter(help_category_id) from object array.
		String id = inputParam.get("id");
		//String id ="10";
		//System.out.print("------id: "+id);
		
		if(serviceId.equals("HelpTopicService")){
			try {
			//	String middlewarePath = System.getProperty("middleware.home");
				InputStream input = getClass().getResourceAsStream("/com/kony/xmlfiles/topics.xml");	
				//	BufferedInputStream br = new BufferedInputStream(input);
				//String separator = System.getProperty("file.separator");				
				//File fXmlFile = new File(br.toString());
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(input);

				doc.getDocumentElement().normalize(); 
		 
				NodeList nList = doc.getElementsByTagName("row");
		 
				for (int count = 0; count < nList.getLength(); count++) {
			 
					Node nNode = nList.item(count);
			 
					//System.out.println("\nCurrent Element :" + nNode.getNodeName());
			 
					if (nNode.getNodeType()== Node.ELEMENT_NODE) {						
						Element eElement = (Element) nNode;	
						String help_topic_id = eElement.getElementsByTagName("field").item(0).getTextContent();
						String name = eElement.getElementsByTagName("field").item(1).getTextContent();
						String help_category_id = eElement.getElementsByTagName("field").item(2).getTextContent();
						String url = eElement.getElementsByTagName("field").item(3).getTextContent();		

						if(help_category_id.equalsIgnoreCase(id)){
							Record record = new Record();
							Param param1 = new Param("help_topic_id", help_topic_id, "String");
							record.setParam(param1);
							Param param2 = new Param("name", name, "String");
							record.setParam(param2);
							Param param3 = new Param("help_category_id", help_category_id, "String");
							record.setParam(param3);
							Param param5 = new Param("url", url, "String");
							record.setParam(param5);
							list_hc.add(record);
						}						
						System.out.println("help_topic_id : " + eElement.getElementsByTagName("field").item(0).getTextContent());
						System.out.println("name : " + eElement.getElementsByTagName("field").item(1).getTextContent());
						System.out.println("help_category_id : " + eElement.getElementsByTagName("field").item(2).getTextContent());
						System.out.println("url : " + eElement.getElementsByTagName("field").item(3).getTextContent());
						
						
		
					}
				}
				Param param_opstatus = new Param("opstatus", "0", "String");
				result.setParam(param_opstatus);

				set.setRecords(list_hc);				
				result.setDataSet(set);
				
	    } catch (Exception e) {
		e.printStackTrace();
	    }
	}
	return result;
}
	public static void main(String args[]) throws Exception{
		HelpTopic help = new HelpTopic();
		
		help.invoke("HelpTopicService", null);
		
	}
	
}


