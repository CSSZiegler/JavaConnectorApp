package com.kony.samplejavaservice;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import com.konylabs.middleware.common.JavaService;
import com.konylabs.middleware.dataobject.Dataset;
import com.konylabs.middleware.dataobject.Param;
import com.konylabs.middleware.dataobject.Record;
import com.konylabs.middleware.dataobject.Result;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;

public class HelpKeyword implements JavaService {
	 
	public Object invoke(String serviceId, Object[] objectArray) throws Exception {
		
		Result result = new Result();
		Dataset set = new Dataset("helpKeyword");
		ArrayList<Record> list_hk = new ArrayList<Record>();
		
		if(serviceId.equals("HelpKeywordService")){	 
	    try {
			/*String middlewarePath = System.getProperty("middleware.home");
			String separator = System.getProperty("file.separator");				
			File fXmlFile = new File(middlewarePath + separator + "samplefiles" + separator +"JavaConnectorFiles"+ separator +"keyword.xml");*/ 
			InputStream input = getClass().getResourceAsStream("/com/kony/xmlfiles/keyword.xml");	
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(input);	
			doc.getDocumentElement().normalize();
		 
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
		 
			NodeList nList = doc.getElementsByTagName("row");
		 
			System.out.println("----------------------------Length: "+nList.getLength());
		 
			for (int count = 0; count < nList.getLength(); count++) {
		 
				Node nNode = nList.item(count);
		 
				System.out.println("\nCurrent Element :" + nNode.getNodeName());
		 
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Record record = new Record();
					Element eElement = (Element) nNode;	
					String hk_id = eElement.getElementsByTagName("field").item(0).getTextContent();
					String hk_name = eElement.getElementsByTagName("field").item(1).getTextContent();
					Param param1 = new Param("hkid", hk_id, "String");
					record.setParam(param1);
					Param param2 = new Param("hkname", hk_name, "String");
					record.setParam(param2);
					System.out.println("help_keyword_id : " + eElement.getElementsByTagName("field").item(0).getTextContent());
					System.out.println("name : " + eElement.getElementsByTagName("field").item(1).getTextContent());
					list_hk.add(record);
	
				}
			}
			Param param_opstatus = new Param("opstatus", "0", "String");
			result.setParam(param_opstatus);
			set.setRecords(list_hk);				
			result.setDataSet(set);
			
	} catch (Exception e) {
		e.printStackTrace();
	}
	}
	return result;
	}
	public static void main(String args[]) throws Exception{
		HelpKeyword helpk = new HelpKeyword();
		
		helpk.invoke("HelpKeywordService", null);
		
	}
}